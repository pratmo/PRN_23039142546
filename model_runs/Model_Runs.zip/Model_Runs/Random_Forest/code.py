import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error

# Load the dataset
# Make sure the file `df_bax_cleaned_to_view_outliers.csv` is in the same directory.
try:
    df = pd.read_csv('df_bax_cleaned_to_view_outliers.csv')
except FileNotFoundError:
    print("Error: The file 'df_bax_cleaned_to_view_outliers.csv' was not found.")
    # You might want to exit or use a placeholder dataframe here.
    exit()

# --- 1. Data Preprocessing and Feature Engineering ---

# Convert 'Date' column to datetime objects and set it as the index
df['Date'] = pd.to_datetime(df['Date'])
df.set_index('Date', inplace=True)

# Select only the 'Price' column for our forecasting task
data = df[['Price']].copy()

# Create lagged features to convert the time series problem into a supervised learning problem.
# We will use the prices from the last 1, 2, 3, 5, and 10 days to predict the current day's price.
lags = [1, 2, 3, 5, 10]
for lag in lags:
    data[f'Price_lag_{lag}'] = data['Price'].shift(lag)

# Drop any rows with NaN values that were created by the lagging process.
data.dropna(inplace=True)

# Define the feature set (X) and the target variable (y)
X = data.drop('Price', axis=1)
y = data['Price']

# --- 2. Data Splitting ---

# We need to split the data in a time-based manner, not randomly.
# Let's use the first 80% of the data for training and the last 20% for testing.
split_point = int(len(X) * 0.8)
X_train, X_test = X[:split_point], X[split_point:]
y_train, y_test = y[:split_point], y[split_point:]

# Check the shapes of the splits
print(f"Training data shape: {X_train.shape}, {y_train.shape}")
print(f"Testing data shape: {X_test.shape}, {y_test.shape}")

# --- 3. Model Training ---

# Initialize and train the Random Forest Regressor model.
# n_estimators is the number of trees in the forest.
# random_state ensures reproducibility of results.
rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
print("\nTraining Random Forest model...")
rf_model.fit(X_train, y_train)
print("Training complete.")

# --- 4. Making Predictions ---

# Use the trained model to make predictions on the test data.
predictions = rf_model.predict(X_test)

# --- 5. Model Evaluation ---

# Calculate and print the evaluation metrics.
mae = mean_absolute_error(y_test, predictions)
rmse = np.sqrt(mean_squared_error(y_test, predictions))

print(f"\nMean Absolute Error (MAE): {mae:.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")

# --- 6. Visualization ---

# Plot the actual vs. predicted prices
plt.figure(figsize=(12, 6))
plt.plot(y_test.index, y_test, label='Actual Price', color='blue')
plt.plot(y_test.index, predictions, label='Predicted Price', color='red', linestyle='--')
plt.title('BAX Price Prediction: Random Forest Regressor')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.grid(True)
plt.show()
